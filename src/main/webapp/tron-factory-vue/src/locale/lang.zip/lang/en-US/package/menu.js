export default {
  nodesManage: 'Nodes Manage',
  configuration: 'Configuration',
  ecologyApp: 'Ecology App',
  walletCLI: 'Wallet CLI',
  tronLink: 'TronLink',
}
