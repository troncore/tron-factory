/**
 * sign in or sign out
 */
export default {
  account: '账号',
  email: '邮箱',
  password: '密码',
  rememberPassword: '记住密码',
  signInTestAccount: '登录测试账号',
  signIn: '登录',
  helpTips: {
    account: '请输入邮箱',
    email: '请输入邮箱',
    password: '请输入密码',
    emailError: '邮箱格式错误',
    emailOrPwdError: '邮箱或密码错误',
  }
}
