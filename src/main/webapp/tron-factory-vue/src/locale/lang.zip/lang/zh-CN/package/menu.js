export default {
  nodesManage: '节点管理',
  configuration: '配置',
  ecologyApp: '生态应用',
  walletCLI: 'Wallet CLI',
  tronLink: 'TronLink',
}
